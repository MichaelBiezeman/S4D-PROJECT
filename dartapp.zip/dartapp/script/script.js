function splash(param) {
 var time = param;
 setTimeout(function () {
   $('#splashscreen').fadeOut();
 }, time);
}
// $(document).ready(function(){
//  $('#splashscreen').on(function() { 
//         $(this).fadeOut(3000);
//  });
// });