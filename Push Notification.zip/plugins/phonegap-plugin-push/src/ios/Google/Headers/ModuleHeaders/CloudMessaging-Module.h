#if defined(__has_include)
# if __has_include(<Google/CloudMessaging.h>)
#  include <Google/CloudMessaging.h>
# endif
#endif
